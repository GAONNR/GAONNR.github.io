---
layout: post
title: 본문용으로 웹폰트 (Kopub바탕) 적용했습니다.
category: Setting
---

예전에 웹폰트를 추가했더니 사이트 접속이 느려지는 바람에 웹폰트를 날렸었는데, 갑자기 또 마음이 변해서 이정도면 괜찮지 않을까 해서 넣어봤어요.

새로 넣은 웹폰트는 본문에만 적용되구요, Kopub바탕입니다.

구글의 [Font Earlyaccess](https://www.google.com/fonts/earlyaccess)에서 따와서 적용했습니다.
