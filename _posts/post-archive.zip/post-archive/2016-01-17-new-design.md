---
layout: post
title: 블로그 디자인 또 갈아엎었습니다.
category: Setting
---

그전엔 Jekyll-Bootstrap을 썼습니다만, 왠지 어떻게 해야 할지를 잘 몰라서 뭔가 정보가 쬐끔 더 있어보이는 Jekyll-Now를 clone했어요. (이건 사실 제가 몰라서 그러는 거고, 좀만 배우면 이런거 상관없이 쓸듯한데)

테마는 Lanyon Theme 적용했습니다. 본문 서체가 Serif체라 따로 설정 안한 윈도우 환경에서 어떻게 보일지 궁금하긴 한데. 괜찮겠죠 뭐.
