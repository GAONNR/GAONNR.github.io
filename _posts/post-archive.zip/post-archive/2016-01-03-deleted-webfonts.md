---
layout: post
title: 웹폰트 날렸습니다.
category: Setting
---

원래는 Spoqa Han Sans KR/JP가 적용되어 있었는데요... 긱사에서 테스트해볼 때는 별로 문제점을 못 느꼈는데

![](https://lh3.googleusercontent.com/182zoTTFxbNJK3L8mCDQjR8xS5um_Y2AyMy6h8VDUG2ECNCXz4O82Dos28WYLENfu-YL0XRcgiml3RFz5hC140RtWcgelQ9BMn-5N1qTaZnWZ-UmX_7F0hWw4303_af_eRojc-qPjX1tJOiH4SR_KlINqqSqVV6XlynG2R1L5anZhEm9dZ-T11R2tZ3GZHVyx-w5eHTfdRdXdOxS2GW98TIk0VHnTgVVZ8lKwN6qT_x0H1Eq1gUFtzblJijVdahw1N-Pue0zZRf-pUq6XDFDz-Dj7VHuytfZKk8izpE93OMXIDnBShUspd5zlNo69nLwuWoUGcQNKIePGZ8aMUd4RNIow3o0hTA6jaHgYtxzsyB7YhLvQXLGCKcu9GlzuwLdViIT6Tkviqy7O-zVcevxQYb5DfhcaLg76zNk9wcjMo83K9-kzEcxpLtbJetdDzxlK3HT1C5VhcIX1hUQYnGSwjlAWfxXUgG64zpc-XNM1bExPDNWmZB6g1_z0ydOI9wD76Wlo33nvj8Y0O8jbRYdryOgYFTMS801L1cSOPU7DDE0oOVauRC9KxxnShJoCNdTbQBJ=w596-h101-no)

위 사진과 같이 웹폰트 덕분에 로딩이 무지막지하게 느려진다는 제보를 받아서 그냥 날리기로 했습니다 ㅠ

여러분 웹브라우저 이쁜폰트 기본으로 설정하시고 쓰세요

(아니면 맥 쓰던가)
