---
layout: post
title: 삿포로 여행 3일차 - 유키미쿠와 삿포로 팩토리, 삿포로 구도청사와 시계탑, 라면 거리, 스스키노 아이스 월드, 그리고 TV타워
category: Trip
---

오늘은 어제보다 한시간 정도 일찍 기상해서 일정을 시작...하기로 했었는데, 가스 공급의 문제로 숙소에 잠깐 온수가 나오지 않은 덕분에 출발 일정이 1시간 늦어졌다. 그래도 이미 있는 계획을 엎을 수는 없으니, 부랴부랴 일정에 맞춰 움직이기로 했다.

어찌저찌 유키미쿠 관련 굿즈들을 파는 삿포로 팩토리 홀에 도착.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_102654.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_115632.jpg" style="height: 480px;">
  <span class="italics">삿포로 팩토리 홀.</span>
</p>

줄이 꽤 길었다. 윗윗 사진에서 보이는 줄이 입구로 바로 들어가는 줄이 아니고, 저기서 두 번을 더 꺾어 들어가야 입구가 나온다. 그 정도로 길었고, 설상가상으로 눈까지 내렸기에 기다리는 것이 꽤 고됐다.

한 두 시간을 줄을 서서 기다렸을까, 드디어 행사장 안으로 들어갈 수 있었다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_124132.jpg" style="width: 480px;">
  <span class="italics">행사장 내부. (또) 줄을 서서 유키미쿠 관련 굿즈들을 살 수 있는 창구와, 기업들의 미쿠 관련 부스들이 있었다.</span>
</p>

유키미쿠 굿즈를 많이 살 계획은 없었는데, 인파에 휘말려 어찌어찌 굿즈 구매 줄 사이에 끼게 되어서, 이대로 아무것도 안 사고 가자니 뻘줌할 것 같아 유키미쿠 스포츠 타월을 하나 샀다. 근데 사실 이걸 어디에 써야 할지는 잘 모르겠다. 원래는 안경수건인 줄 알고 산 건데....

물건을 산 뒤에는 기업 부스를 둘러봤다. 유키미쿠 인형과 피규어, 스포츠 고글(!!), 미쿠 VR이 전시된 부스들이 있었다. 뭐 볼 게 많이 있었던 건 아니고, 그냥 이런 게 있구나~ 하는 정도로 둘러봤다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_123559.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_123623.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_123627.jpg" style="height: 480px;">
  <span class="italics">유키미쿠 관련 인형과 피규어들. 나머지 부스는 미처 찍지 못했다. 사실 찍을만한 게 딱히 없기도 했고....</span>
</p>

삿포로 팩토리 홀을 나온 후엔 바로 앞에 있는 삿포로 팩토리로 향했다. 이곳에도 미쿠미쿠한 것들이 많았다. 자세한 건 사진으로 대신.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_125100.jpg" style="width: 480px;">
  <span class="italics">미쿠 VR...과 키넥트 뭐시기. 들어가 보진 않았다. 그저 일러스트가 이뻐서 한장 찍었다.</span>
</p>


<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_131212.jpg" style="width: 480px;">
  <span class="italics">뭔가 무대가 있었다. 나중에 크립톤(미쿠 소속사(?)) 관계자로 보이는 사람이 올라와서 뭐라뭐라 말을 하던데, 알아들을 수 없었다.</span>
</p>


<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_131747.jpg" style="height: 480px;">
  <span class="italics">잠깐 쉬면서 먹은 크레페 사진 한 장. 이치고 뭐시기... 하는 크레페였는데, 정확히 기억이 안 난다.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_133256.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_133626.jpg" style="height: 480px;">
  <span class="italics">보컬로이드 상들. 미쿠 귀여워요 미쿠.</span>
</p>

좀 더 안쪽으로 들어가니 치토세 공항에서 봤던 것과 비슷한 유키미쿠 박물관(?)이 있었다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134507.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134520.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134528.jpg" style="height: 480px;">
  <span class="italics">2016년 버전 유키미쿠 일러스트.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134700.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134746.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_134801.jpg" style="width: 480px;">
  <span class="italics">역대 유키미쿠 넨도로이드들. 휴대폰 카메라가 안 좋아서 사진이 잘 나오지 않았다. 다음 폰은 꼭 카메라 좋은 걸로 사야지.</span>
</p>

유키미쿠 관련 관람은 이 정도로 끝내고, 좀 더 현실에 충실한(?) 관광을 하기 위해 이동했다. 먼저 도착한 곳은 삿포로 구도청사였다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_142059.jpg" style="width: 480px;">
  <span class="italics">삿포로 구도청사의 외부. 고-풍 스러운 건물의 디자인과 그 앞에 있는 귀여운 눈사람이 인상적이다.</span>
</p>

외관만큼이나 내부도 아주 고급진 건물이었다. 내부는 일종의 박물관화가 되어있었는데, 삿포로의 역대 수장들(?)의 사진들, 삿포로와 교류한 여러 나라의 선물들 등을 볼 수 있었다.


<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_143435.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_143836.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_144755.jpg" style="width: 480px;">
  <span class="italics">삿포로 구도청사의 내부.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/Method_Sample.jpg" style="height: 480px;">
  <span class="italics">여담이지만, 이 삿포로 구도청사는 애니메이션 '천체의 메소드' 등장인물들의 학교로 나온 곳이라고 한다.</span>
</p>

다음 목적지는 삿포로 시계탑이었다. 사실 이곳은 크게 기대하고 오진 않았다. 오기 전에 삿포로에 대해 적당히 검색을 해봤었는데, 삿포로 시계탑은 유명하기는 하지만 정작 볼 것은 없는 곳이라는 평이 매우 많았기 때문이었다. 뭐... 실제로 크게 감탄할 만한 것은 없었고, 삿포로의 역사 등등이 기록된 판넬이 전시되어 있었는데, 나는 일본어를 잘 하지 못하니 알아들을 수 없었다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_151223.jpg" style="height: 480px;">
  <span class="italics">삿포로 시계탑의 외부.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_151527.jpg" style="height: 480px;">
  <span class="italics">입장료를 냈더니, 유키미쿠가 인쇄된(!) 입장권과 함께 유키미쿠 파일(!!)을 받았다! 전혀 예상치 못한 곳에서 유키미쿠가 튀어나와 버려서 적잖이 (좋은 의미로) 당황했다.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_153551.jpg" style="width: 480px;">
  <span class="italics">뜻밖의 유키미쿠에 너무 감동받아서 방명록에 낙서를 끄적거리고 왔다. 유키미쿠님 흥하세요.</span>
</p>

시계탑 관광을 마치고, 다들 적당히 배고픈 때여서, 스스키노 역 근처의 라멘 거리로 향했다. 라면 거리라고 해서 엄청 크고 거창했던 것은 아니고, 골목길 하나에 라면집이 모여 있는 정도였다. 창 너머로 적당히 비어 있는 음식점을 찾다가, '이치쿠라'라는 라면집 안으로 들어갔다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_163107.jpg" style="width: 480px;">
  <span class="italics">우리가 택한 라멘집. 왜 이 라멘집을 택했느냐 하면...</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_160640.jpg" style="height: 480px;">
  <span class="italics">'등-째응'이란 음식을 들어본 적도 먹어본 적도 없기 때문이었다(?). 번역기 오류인 것 같다.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_161135.jpg" style="width: 480px;">
  <span class="italics">어쨌든 일본, 그 중에서도 라멘거리의 음식점 답게 라멘은 상당히 맛있었다. 한국에서 먹던 것과는 확연히 다른 맛....</span>
</p>

밥을 다 먹고 어슬렁어슬렁 걷다 보니, 얼음으로 만든 조각상들이 보이기 시작했다. '스스키노 아이스 월드'라는 축제의 작품들인 듯 했다. 마침 해도 져 있겠다, 투명한 얼음조각들이 조명을 받으니 참으로 예뻤다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185143.jpg" style="width: 480px;">
  <span class="italics">얼음 조각들이 거리를 따라 늘어서 있었다.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185251.jpg" style="width: 480px;">
  <span class="italics">예전에도 이거랑 비슷한 컨셉의 작품이 있었다는 걸 인터넷에서 봤다. 그 때는 물고기에서 핏물이 뚝뚝 떨어져서 호러스러웠다고 하던데, 이번에는 뭐 해결을 해서 전시했겠지...?</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185339.jpg" style="width: 480px;">
  <span class="italics">이 축제의 홍보 캐릭터인가 보다. 꽤 귀여웠다. 유키미쿠랑 콜라보레이션을 해도 좋겠다는 생각을 잠깐 했다.</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185359.jpg" style="width: 480px;">
  <span class="italics">참...이슬...이라고...?</span>
</p>

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185509.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_185555.jpg" style="height: 480px;">
  <span class="italics">기타 조각상들.</span>
</p>

오늘의 라스트 목적지는 TV타워. 예전에 도쿄에 놀러갔을 때 도쿄도청 전망대에서 경치를 보지 못한 한이 있었기 때문에, 이번에는 야경을 잘 보고 오자고 마음먹었다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_191321.jpg" style="height: 480px;">
</p>

그런데 입장료가 꽤 비쌌다. 성인 8천원, 고교생 6천원? 정도였던 것 같다. 고작 타워 주제에 대체 얼마나 볼거리가 있길래 이정도로 입장료를 많이 받아먹나 생각했다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_194544.jpg" style="height: 480px;">
  <span class="italics">이 거꾸로 된 당근같은 아저씨는 뭐지 했는데 아마 TV타워를 캐릭터화한 것 같다. 왠지 나도 할 수 있을 것 같은 디자인이다.</span>
</p>

줄을 서서 어찌어찌 입장권을 샀지만 안에도 줄이 길었다. 그나마 다행이었던 것은 사람들이 들어갔다 나오는 게 빠른 편이라서, 줄이 비교적 쑥쑥 줄어들었다는 것이다. 한 15분 정도 서서 기다렸을까, 엘리베이터를 타고 TV타워의 맨 꼭대기로 올라갈 수 있었다. 자 이제 야경을 구경할 수 있게 되었는데,

<p align="CENTER">
우와아앙?
<br>
</p>

야경이 저어어엉말 예뻤다. 이 야경의 1/10이라도 담아 보고자 열심히 폰카메라의 셔터를 눌러 댔지만 도저히 담을 수 없었다. 만약 이 글을 보는 사람 중 삿포로에 여행가는 사람이 있다면, 돈이 아깝다고 생각하지 말고 TV타워만큼은 꼭 올라가 보길 권한다. 야경을 보는 순간 티켓 값은 잊어버리리라고 자신한다. 그 정도로 예뻤다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_200246.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_200001.jpg" style="height: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_200021.jpg" style="width: 480px;">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_200119.jpg" style="height: 480px;">
  <span class="italics">(맨눈으로 보면)정말 이쁜 야경. 다음 폰은 카메라가 좋아야겠다는 생각이 다시금 들었다.</span>
</p>

연신 감탄사를 연발하며 야경 관광을 끝내니, 엘리베이터로 내려가는 출구와 계단으로 내려가는 출구 중 하나를 선택하는 옵션이 있었다. 그때는 마냥 기분이 좋아서 계단으로 내려가기로 했는데, 몇 계단을 내려가자마자 '음...이건 좀 아니다'라는 생각이 들었다. 춥고, 좀 바람도 많이 불었다.... 만약 타워에 오는 사람이 있다면 내려갈 때는 꼭 엘리베이터를 쓰세요.

아래에 내려가니 휴게실? 로비? 같은 곳 안에 가챠(뽑기)가 있었다. 다른 가챠였으면 그냥 무시하고 지나갔겠지만.... 이럴 수가! 가챠 품목 중 유키미쿠가 있는 것이 아닌가. 나는 당장 주머니에서 동전을 꺼내 가챠를 돌렸지만...  
실패했다.
같이 가챠를 돌렸던 친구들은 다 나왔지만, 나만 유키미쿠를 획득하지 못했다.... 한끼 식사값을 가챠로 날려버렸는데도, 얻지 못했다. 눈물을 흘리는 심장을 부여잡고, 나는 그렇게 유키미쿠를 얻지 못한 채 타워를 내려가야 했다.

<p align="CENTER">
  <img src="{{ site.baseurl }}/images/2016_02/06/IMG_20160206_203300.jpg" style="height: 480px;">
  <span class="italics">너무 마음이 아픈 나머지, 김이 서린 창문에 미쿠를 그리고 떠났다. 다른 창문에도 뭔가 이것저것 많이 그려져 있더라.</span>
</p>

그 후 숙소에 도착. 친구들과 놀다가 취침했다. 뭔가 제대로 여행한다는 느낌이 들었던 날이었지만, 동시에 얻지 못한 가챠 때문에 마음이 아픈 날이기도 했다....
